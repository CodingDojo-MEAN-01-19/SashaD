const rabbitController = require('./rabbits');

module.exports = {
    rabbitController
};