const quoteController = require('./quotes');

module.exports = {
    quoteController
};